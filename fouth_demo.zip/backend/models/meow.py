import pandas as pd

df = pd.read_csv("data/DataCo_Weekly.csv")

south = df[df["Store"] == "South America"]

print(south[["Date", "Weekly_Sales"]])

print("\nMax:", south["Weekly_Sales"].max())
print("Mean:", south["Weekly_Sales"].mean())
print("Last:", south["Weekly_Sales"].iloc[-1])